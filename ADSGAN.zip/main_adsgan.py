"""Anonymization through Data Synthesis using Generative Adversarial Networks:
A harmonizing advancement for AI in medicine (ADS-GAN) Codebase.

Reference: Jinsung Yoon, Lydia N. Drumright, Mihaela van der Schaar, 
"Anonymization through Data Synthesis using Generative Adversarial Networks (ADS-GAN):
A harmonizing advancement for AI in medicine," 
IEEE Journal of Biomedical and Health Informatics (JBHI), 2019.
Paper link: https://ieeexplore.ieee.org/document/9034117
Last updated Date: December 22th 2020
Code author: Jinsung Yoon (jsyoon0823@gmail.com)
-----------------------------
main_adsgan.py
- Main function for ADSGAN framework
(1) Load data
(2) Generate synthetic data
(3) Measure the quality and identifiability of generated synthetic data
"""

#%% Import necessary packages
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import argparse

# synth_data 저장
import pandas as pd
import numpy as np

#%% Import necessary functions
from data_loader import load_EHR_data
from adsgan import adsgan
from metrics.feature_distribution import feature_distribution
from metrics.compute_wd import compute_wd
from metrics.compute_identifiability import compute_identifiability


#%% Experiment main function
def exp_main(args):
  
  # Data loading
  orig_data = load_EHR_data()
  print("Finish data loading")
  
  # Generate synthetic data
  params = dict() # 파라미터들을 딕셔너리 형태로 저장
  params["lamda"] = args.lamda # lamda: 합성 데이터의 신원식별성(Identifiability)과 데이터 품질(Quality)을 조절하는 하이퍼파라미터
  params["iterations"] = args.iterations # iterations: ADS-GAN의 훈련 반복 횟수를 지정
  params["h_dim"] = args.h_dim # h_dim: 합성 모델의 은닉 상태 차원(차원 수)
  params["z_dim"] = args.z_dim # z_dim: 무작위 상태의 차원(차원 수)으로, 합성 모델의 무작위성을 결정
  params["mb_size"] = args.mb_size # mb_size: 미니 배치의 샘플 개수, 모델 훈련 시 한 번에 사용할 데이터 샘플 수를 의미

  # 합성 데이터 생성
  synth_data = adsgan(orig_data, params)
  print("Finish synthetic data generation")

  # synth_data 저장(추가)
  output_path = "synth_data.csv"

  try:
      # 데이터를 판다스의 데이터프레임으로 변환
      df_synth_data = pd.DataFrame(synth_data, columns=[f"Feature{i + 1}" for i in range(synth_data.shape[1])])

      # 데이터를 CSV 파일로 저장
      df_synth_data.to_csv(output_path, index=False)
      print(f"합성 데이터가 성공적으로 {output_path}에 저장되었습니다.")
  except FileNotFoundError as e:
      print("파일 경로를 찾을 수 없습니다:", e)
  except Exception as e:
      print("오류가 발생하여 데이터를 저장할 수 없습니다:", e)
  else:
      print("정상적으로 데이터 저장이 완료되었습니다.")

  # 성능 측정 시작(Performance measures)
  ## (1) 특성 분포(Feature distributions)
  ### 합성 데이터와 원본 데이터의 특성 분포를 비교하여 성능을 측정
  feat_dist = feature_distribution(orig_data, synth_data)
  print("Finish computing feature distributions")
  
  # (2) Wasserstein Distance (WD)
  ## Wasserstein Distance를 계산하여 합성 데이터와 원본 데이터의 분포의 차이를 측정
  print("Start computing Wasserstein Distance")
  wd_measure = compute_wd(orig_data, synth_data, params)
  print("WD measure: " + str(wd_measure)) #wd_measure을 문자열로 변환
    
  # (3) 신원식별성(Identifiability)
  ## 합성 데이터와 원본 데이터 간의 신원식별성(Identifiability)을 측정
  identifiability = compute_identifiability(orig_data, synth_data)
  print("Identifiability measure: " + str(identifiability))

  # 성능 측정 결과와 함께 원본 데이터, 합성 데이터, 성능 측정 값들을 반환
  return orig_data, synth_data, [feat_dist, wd_measure, identifiability]
  
# 스크립트가 직접 실행될 때만 아래 코드블럭이 실행
if __name__ == '__main__':

  # 명령줄에서 입력 받을 인자들을 파싱(Inputs for the main function)
  parser = argparse.ArgumentParser()
  parser.add_argument(
      '--iterations',
      help='number of adsgan training iterations', # ADS-GAN 훈련 반복 횟수에 대한 설명
      default=10000, # 기본값 설정
      type=float) # 정수형으로 파싱
  parser.add_argument(
      '--h_dim',
      help='number of hidden state dimensions', # 은닉 상태 차원에 대한 설명
      default=30, # 기본값 설정
      type=float) # 정수형으로 파싱
  parser.add_argument(
      '--z_dim',
      help='number of random state dimensions', # 무작위 상태 차원에 대한 설명
      default=10, # 기본값 설정
      type=float) # 정수형으로 파싱
  parser.add_argument(
      '--mb_size',
      help='number of mini-batch samples', # 미니 배치 샘플 개수에 대한 설명
      default=128, # 기본값 설정
      type=float) # 정수형으로 파싱
  parser.add_argument(
      '--lamda',
      help='hyper-parameter to control the identifiability and quality', # 신원식별성과 품질 조절을 위한 하이퍼파라미터에 대한 설명
      default=0.1, # 기본값 설정
      type=float) # 실수형으로 파싱

  # 입력된 인자들을 파싱하여 args에 저장
  args = parser.parse_args() 
  
  # 메인 함수 호출(Calls main function)
  orig_data, synth_data, measures = exp_main(args)

  # orig_data, synth_data, measures = exp_main(args)