"""Anonymization through Data Synthesis using Generative Adversarial Networks:
A harmonizing advancement for AI in medicine (ADS-GAN) Codebase.

Reference: Jinsung Yoon, Lydia N. Drumright, Mihaela van der Schaar, 
"Anonymization through Data Synthesis using Generative Adversarial Networks (ADS-GAN):
A harmonizing advancement for AI in medicine," 
IEEE Journal of Biomedical and Health Informatics (JBHI), 2019.
Paper link: https://ieeexplore.ieee.org/document/9034117
Last updated Date: December 22th 2020
Code author: Jinsung Yoon (jsyoon0823@gmail.com)
-----------------------------
data_loader.py
- data loading function for ADSGAN framework
(1) Load data and return pandas dataframe
"""

# Import necessary packages
import pandas as pd

def load_EHR_data():
  """Load EHR data.
  
  Returns:
    orig_data: Original data in pandas dataframe
    orig_data: Original data with one-hot encoding in pandas dataframe
  """
  # Read csv files
  file_name = 'C:/Users/nkm11/Documents/pycharm/ADSGAN/data/data-ori.csv'
  orig_data = pd.read_csv(file_name)

  # Remove NA
  orig_data = orig_data.dropna(axis=0, how='any')

  # # 원핫인코딩 방식
  # onehot_columns = ['SEX', 'SOURCE']
  # orig_data = pd.get_dummies(orig_data, columns=onehot_columns)

  # 원핫인코딩과 라벨인코딩 혼합
  # Label encoding for SEX column: 'M' -> 0, 'F' -> 1
  orig_data['SEX'] = orig_data['SEX'].map({'M': 0, 'F': 1})

  # Label encoding for SOURCE column: 'in' -> 0, 'out' -> 1
  orig_data['SOURCE'] = orig_data['SOURCE'].map({'in': 0, 'out': 1})

  # 원핫 인코딩을 수행할 열 이름 (원핫 인코딩은 다른 열에 대해 수행됨)
  onehot_columns = []  # 이 경우는 라벨 인코딩으로 처리했기 때문에 원핫 인코딩할 열 없음

  # 원핫 인코딩 수행
  orig_data = pd.get_dummies(orig_data, columns=onehot_columns)

  # Remove labels
  # orig_data = orig_data.drop(['death_all','days_to_fu'], axis = 1)
  
  return orig_data

# 인코딩 확인 코드
# data = load_EHR_data()
# print(data.head())