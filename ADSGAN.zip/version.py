import sys
import pkg_resources
# numpy>=1.18.2
# pandas>=1.0.3
# argparse>=1.1
# scipy>=1.3.1
# sklearn>=0.21.3
# tensorflow==1.15.0
# tqdm>=4.36.1


print("Python 버전:", sys.version)

def get_library_version(library_name):
    try:
        version = pkg_resources.get_distribution(library_name).version
        return version
    except pkg_resources.DistributionNotFound:
        return None

libraries = [
    "numpy", "pandas", "argparse", "scipy",
    "scikit-learn", "tensorflow", "tqdm", "protobuf"
]

for library in libraries:
    version = get_library_version(library)
    if version:
        print(f"{library} 버전: {version}")
    else:
        print(f"{library} 라이브러리를 찾을 수 없습니다.")

